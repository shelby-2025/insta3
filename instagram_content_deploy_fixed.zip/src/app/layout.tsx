import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { MainNav } from '@/components/main-nav'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Gerador de Conteúdo para Instagram',
  description: 'Sistema automatizado para geração de conteúdo motivacional e espiritual para Instagram',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <div className="min-h-screen bg-background">
          <header className="border-b">
            <div className="container mx-auto py-4 px-4 flex items-center justify-between">
              <div className="flex items-center">
                <h1 className="text-xl font-bold mr-8">Gerador de Conteúdo</h1>
                <MainNav />
              </div>
            </div>
          </header>
          {children}
        </div>
      </body>
    </html>
  )
}
