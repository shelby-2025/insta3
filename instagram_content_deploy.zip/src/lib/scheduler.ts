// Tipos de configurações para geração de conteúdo
export interface ContentGenerationConfig {
  themes: string[];           // Temas para geração de conteúdo
  includeReligious: boolean;  // Incluir mensagens religiosas
  includeNonReligious: boolean; // Incluir mensagens não religiosas
  imageStyle: string;         // Estilo de imagem preferido
  postCount: number;          // Número de posts a gerar
  storyCount: number;         // Número de stories a gerar
  scheduleTime: string;       // Horário para geração automática
}

// Configuração padrão
export const defaultConfig: ContentGenerationConfig = {
  themes: ['desenvolvimento pessoal', 'espiritualidade', 'superação'],
  includeReligious: true,
  includeNonReligious: true,
  imageStyle: 'paisagens naturais',
  postCount: 1,
  storyCount: 5,
  scheduleTime: '08:00'
};

// Função para salvar configurações
export async function saveConfig(config: ContentGenerationConfig): Promise<boolean> {
  // Em produção, aqui salvaríamos no banco de dados ou localStorage
  localStorage.setItem('contentGeneratorConfig', JSON.stringify(config));
  return true;
}

// Função para carregar configurações
export async function loadConfig(): Promise<ContentGenerationConfig> {
  // Em produção, aqui carregaríamos do banco de dados ou localStorage
  const savedConfig = localStorage.getItem('contentGeneratorConfig');
  return savedConfig ? JSON.parse(savedConfig) : defaultConfig;
}

// Função para agendar geração automática
export function scheduleContentGeneration(config: ContentGenerationConfig, callback: () => void): number {
  // Implementação básica usando setTimeout para demonstração
  // Em produção, usaríamos um sistema mais robusto de agendamento
  
  const now = new Date();
  const [hours, minutes] = config.scheduleTime.split(':').map(Number);
  
  let scheduledTime = new Date(now);
  scheduledTime.setHours(hours, minutes, 0, 0);
  
  // Se o horário já passou hoje, agendar para amanhã
  if (scheduledTime <= now) {
    scheduledTime.setDate(scheduledTime.getDate() + 1);
  }
  
  const timeUntilExecution = scheduledTime.getTime() - now.getTime();
  
  // Retorna o ID do timeout para possível cancelamento
  return window.setTimeout(callback, timeUntilExecution);
}
