// Arquivo para integrar a geração de imagens e textos em um fluxo completo
// e testar o funcionamento do sistema

import { ContentGenerationConfig, defaultConfig } from './scheduler';
import { generateImage, createImagePrompt } from './image-generator';
import { generateText } from './text-generator';
import { ContentItem } from './api';

/**
 * Função para gerar um item de conteúdo completo (imagem + texto)
 * @param type Tipo de conteúdo (post ou story)
 * @param config Configurações de geração de conteúdo
 * @returns Item de conteúdo gerado ou null em caso de erro
 */
export async function generateContentItem(
  type: 'post' | 'story',
  config: ContentGenerationConfig
): Promise<ContentItem | null> {
  try {
    // Selecionar um tema aleatório das configurações
    const theme = config.themes[Math.floor(Math.random() * config.themes.length)];
    
    // Determinar se o conteúdo será religioso com base nas configurações
    let isReligious = false;
    if (config.includeReligious && config.includeNonReligious) {
      // Se ambos estão habilitados, 50% de chance para cada
      isReligious = Math.random() > 0.5;
    } else if (config.includeReligious) {
      isReligious = true;
    } else if (config.includeNonReligious) {
      isReligious = false;
    } else {
      // Se nenhum está habilitado (não deveria acontecer), usar não-religioso como padrão
      isReligious = false;
    }
    
    // Gerar texto
    const textLength = type === 'post' ? 'medium' : 'short';
    const text = await generateText(theme, isReligious, config, textLength);
    if (!text) {
      console.error('Falha ao gerar texto');
      return null;
    }
    
    // Criar prompt para imagem
    const imagePrompt = createImagePrompt(theme, isReligious, config);
    
    // Gerar imagem
    const imageUrl = await generateImage(imagePrompt, config.imageStyle, config);
    if (!imageUrl) {
      console.error('Falha ao gerar imagem');
      return null;
    }
    
    // Criar e retornar o item de conteúdo completo
    return {
      id: Math.random().toString(36).substring(2, 9),
      type,
      imageUrl,
      text,
      createdAt: new Date().toISOString()
    };
  } catch (error) {
    console.error('Erro ao gerar item de conteúdo:', error);
    return null;
  }
}

/**
 * Função para gerar um conjunto completo de conteúdo (posts e stories)
 * @param config Configurações de geração de conteúdo
 * @returns Array de itens de conteúdo gerados
 */
export async function generateFullContentSet(
  config: ContentGenerationConfig = defaultConfig
): Promise<ContentItem[]> {
  const results: ContentItem[] = [];
  const errors: string[] = [];
  
  // Gerar posts
  for (let i = 0; i < config.postCount; i++) {
    try {
      const post = await generateContentItem('post', config);
      if (post) {
        results.push(post);
      } else {
        errors.push(`Falha ao gerar post #${i+1}`);
      }
    } catch (error) {
      errors.push(`Erro ao gerar post #${i+1}: ${error}`);
    }
  }
  
  // Gerar stories
  for (let i = 0; i < config.storyCount; i++) {
    try {
      const story = await generateContentItem('story', config);
      if (story) {
        results.push(story);
      } else {
        errors.push(`Falha ao gerar story #${i+1}`);
      }
    } catch (error) {
      errors.push(`Erro ao gerar story #${i+1}: ${error}`);
    }
  }
  
  // Registrar erros, se houver
  if (errors.length > 0) {
    console.error('Erros durante a geração de conteúdo:', errors);
  }
  
  return results;
}

/**
 * Função para testar o sistema completo
 */
export async function testSystem(): Promise<void> {
  console.log('Iniciando teste do sistema...');
  
  // Testar com configuração padrão
  console.log('Testando com configuração padrão...');
  const defaultResults = await generateFullContentSet();
  console.log(`Gerados ${defaultResults.length} itens de conteúdo com configuração padrão`);
  
  // Testar com configuração personalizada
  const customConfig: ContentGenerationConfig = {
    ...defaultConfig,
    themes: ['gratidão', 'propósito', 'paz'],
    includeReligious: true,
    includeNonReligious: false,
    imageStyle: 'paisagem montanhosa ao amanhecer',
    postCount: 2,
    storyCount: 3
  };
  
  console.log('Testando com configuração personalizada...');
  const customResults = await generateFullContentSet(customConfig);
  console.log(`Gerados ${customResults.length} itens de conteúdo com configuração personalizada`);
  
  console.log('Teste do sistema concluído!');
}

// Executar teste se este arquivo for executado diretamente
if (typeof window !== 'undefined' && window.location.pathname.includes('test')) {
  testSystem().catch(console.error);
}
