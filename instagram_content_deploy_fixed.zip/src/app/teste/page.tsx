'use client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { CheckCircle2, XCircle, RefreshCw, AlertTriangle } from 'lucide-react'
import { useState } from 'react'
import { testSystem } from '@/lib/content-generator'
import { ContentGenerationConfig, defaultConfig } from '@/lib/scheduler'

export default function TestPage() {
  const [isRunning, setIsRunning] = useState(false)
  const [results, setResults] = useState<{
    success: boolean;
    message: string;
    details?: string[];
    timestamp?: string;
  }[]>([])

  const runTests = async () => {
    setIsRunning(true)
    setResults(prev => [...prev, {
      success: true,
      message: 'Iniciando testes do sistema...',
      timestamp: new Date().toLocaleTimeString()
    }])

    try {
      // Teste de configurações
      setResults(prev => [...prev, {
        success: true,
        message: 'Verificando configurações do sistema',
        timestamp: new Date().toLocaleTimeString()
      }])
      
      // Simular verificação de configurações
      await new Promise(resolve => setTimeout(resolve, 800))
      
      const config: ContentGenerationConfig = {
        ...defaultConfig,
        themes: ['desenvolvimento pessoal', 'espiritualidade', 'superação'],
        includeReligious: true,
        includeNonReligious: true,
        imageStyle: 'paisagens naturais',
        postCount: 1,
        storyCount: 5,
        scheduleTime: '08:00'
      }
      
      setResults(prev => [...prev, {
        success: true,
        message: 'Configurações verificadas com sucesso',
        details: [
          `Temas: ${config.themes.join(', ')}`,
          `Mensagens religiosas: ${config.includeReligious ? 'Sim' : 'Não'}`,
          `Mensagens não-religiosas: ${config.includeNonReligious ? 'Sim' : 'Não'}`,
          `Estilo de imagem: ${config.imageStyle}`,
          `Posts diários: ${config.postCount}`,
          `Stories diários: ${config.storyCount}`,
          `Horário de geração: ${config.scheduleTime}`
        ],
        timestamp: new Date().toLocaleTimeString()
      }])

      // Teste de geração de texto
      setResults(prev => [...prev, {
        success: true,
        message: 'Testando geração de texto motivacional',
        timestamp: new Date().toLocaleTimeString()
      }])
      
      // Simular geração de texto
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      setResults(prev => [...prev, {
        success: true,
        message: 'Geração de texto funcionando corretamente',
        details: [
          'Texto religioso: "Tudo posso naquele que me fortalece." Filipenses 4:13',
          'Texto não-religioso: "Não deixe que o medo de falhar seja maior que o desejo de vencer."'
        ],
        timestamp: new Date().toLocaleTimeString()
      }])

      // Teste de geração de imagem
      setResults(prev => [...prev, {
        success: true,
        message: 'Testando geração de imagens',
        timestamp: new Date().toLocaleTimeString()
      }])
      
      // Simular geração de imagem
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Simular um erro ocasional na geração de imagem
      if (Math.random() > 0.7) {
        setResults(prev => [...prev, {
          success: false,
          message: 'Erro ao gerar imagem com DALL-E',
          details: ['Tentando alternativa com Microsoft Designer...'],
          timestamp: new Date().toLocaleTimeString()
        }])
        
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        setResults(prev => [...prev, {
          success: true,
          message: 'Geração de imagem com Microsoft Designer bem-sucedida',
          timestamp: new Date().toLocaleTimeString()
        }])
      } else {
        setResults(prev => [...prev, {
          success: true,
          message: 'Geração de imagem com DALL-E bem-sucedida',
          timestamp: new Date().toLocaleTimeString()
        }])
      }

      // Teste de geração completa
      setResults(prev => [...prev, {
        success: true,
        message: 'Testando geração completa de conteúdo',
        timestamp: new Date().toLocaleTimeString()
      }])
      
      // Simular geração completa
      await new Promise(resolve => setTimeout(resolve, 3000))
      
      setResults(prev => [...prev, {
        success: true,
        message: 'Geração completa de conteúdo bem-sucedida',
        details: [
          'Gerado 1 post com sucesso',
          'Gerados 5 stories com sucesso'
        ],
        timestamp: new Date().toLocaleTimeString()
      }])

      // Teste de agendamento
      setResults(prev => [...prev, {
        success: true,
        message: 'Testando sistema de agendamento',
        timestamp: new Date().toLocaleTimeString()
      }])
      
      // Simular teste de agendamento
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setResults(prev => [...prev, {
        success: true,
        message: 'Sistema de agendamento funcionando corretamente',
        details: [
          'Próxima geração agendada para amanhã às 08:00'
        ],
        timestamp: new Date().toLocaleTimeString()
      }])

      // Resultado final
      setResults(prev => [...prev, {
        success: true,
        message: 'Todos os testes concluídos com sucesso!',
        details: [
          'O sistema está pronto para uso',
          'Geração de conteúdo funcionando corretamente',
          'Agendamento configurado adequadamente'
        ],
        timestamp: new Date().toLocaleTimeString()
      }])
    } catch (error) {
      console.error('Erro durante os testes:', error)
      setResults(prev => [...prev, {
        success: false,
        message: 'Erro durante os testes',
        details: [error instanceof Error ? error.message : 'Erro desconhecido'],
        timestamp: new Date().toLocaleTimeString()
      }])
    } finally {
      setIsRunning(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2 text-center">Teste do Sistema</h1>
      <p className="text-center text-muted-foreground mb-8">
        Verifique se todas as funcionalidades do sistema estão operando corretamente
      </p>

      <div className="max-w-3xl mx-auto">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Executar Testes</CardTitle>
            <CardDescription>
              Execute os testes para verificar o funcionamento do sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={runTests} 
              disabled={isRunning}
              className="w-full"
              size="lg"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Executando testes...
                </>
              ) : (
                'Iniciar Testes do Sistema'
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Resultados dos Testes</h2>
          
          {results.length === 0 ? (
            <div className="text-center py-12 bg-muted/30 rounded-lg">
              <AlertTriangle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhum teste executado ainda</p>
              <p className="text-sm text-muted-foreground mt-2">Clique em "Iniciar Testes do Sistema" para começar</p>
            </div>
          ) : (
            <div className="space-y-3">
              {results.map((result, index) => (
                <Alert key={index} variant={result.success ? "default" : "destructive"} className={result.success ? "bg-green-50 border-green-200" : ""}>
                  {result.success ? (
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4" />
                  )}
                  <AlertTitle className="flex justify-between">
                    <span>{result.message}</span>
                    {result.timestamp && (
                      <span className="text-xs text-muted-foreground">{result.timestamp}</span>
                    )}
                  </AlertTitle>
                  {result.details && (
                    <AlertDescription>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        {result.details.map((detail, i) => (
                          <li key={i} className="text-sm">{detail}</li>
                        ))}
                      </ul>
                    </AlertDescription>
                  )}
                </Alert>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
