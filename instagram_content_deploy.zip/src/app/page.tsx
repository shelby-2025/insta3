'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Download, Image, MessageSquare, RefreshCw, Settings, Calendar } from 'lucide-react'
import { useEffect, useState } from 'react'
import { ContentItem, generateContent, getContent } from '@/lib/api'
import Link from 'next/link'

export default function Home() {
  const [content, setContent] = useState<ContentItem[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadInitialContent = async () => {
      try {
        const initialContent = await getContent();
        setContent(initialContent);
      } catch (error) {
        console.error('Erro ao carregar conteúdo inicial:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadInitialContent();
  }, []);

  const posts = content.filter(item => item.type === 'post');
  const stories = content.filter(item => item.type === 'story');

  const handleGenerateContent = async () => {
    setIsGenerating(true);
    
    try {
      const newContent = await generateContent();
      setContent(newContent);
    } catch (error) {
      console.error('Erro ao gerar conteúdo:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (item: ContentItem) => {
    // Em uma implementação real, aqui teríamos o código para baixar a imagem
    alert(`Download do item ${item.id} iniciado`);
  };

  const ContentCard = ({ item }: { item: ContentItem }) => (
    <Card className="p-4 mb-4 hover:shadow-md transition-shadow">
      <div className="aspect-square bg-muted rounded-md mb-3 flex items-center justify-center">
        <Image className="h-12 w-12 text-muted-foreground" />
      </div>
      <p className="text-sm mb-3">{item.text}</p>
      <div className="flex justify-between">
        <span className="text-xs text-muted-foreground">
          {new Date(item.createdAt).toLocaleDateString()}
        </span>
        <Button size="sm" variant="outline" onClick={() => handleDownload(item)}>
          <Download className="h-4 w-4 mr-2" />
          Baixar
        </Button>
      </div>
    </Card>
  );

  if (isLoading) {
    return (
      <main className="container mx-auto py-8 px-4 flex items-center justify-center min-h-[80vh]">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 mx-auto animate-spin mb-4" />
          <p>Carregando conteúdo...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Gerador de Conteúdo para Instagram</h1>
          <p className="text-muted-foreground mb-6">
            Gere automaticamente imagens e mensagens motivacionais para seu perfil
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button 
              onClick={handleGenerateContent} 
              disabled={isGenerating}
              className="flex-1 max-w-xs mx-auto sm:mx-0"
              size="lg"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Gerando conteúdo...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Gerar novo conteúdo
                </>
              )}
            </Button>
            
            <div className="flex gap-2 justify-center">
              <Link href="/configuracoes">
                <Button variant="outline" size="lg">
                  <Settings className="h-4 w-4 mr-2" />
                  Configurações
                </Button>
              </Link>
              
              <Link href="/agendamento">
                <Button variant="outline" size="lg">
                  <Calendar className="h-4 w-4 mr-2" />
                  Agendamento
                </Button>
              </Link>
            </div>
          </div>
        </div>

        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="posts">
              <MessageSquare className="h-4 w-4 mr-2" />
              Posts ({posts.length})
            </TabsTrigger>
            <TabsTrigger value="stories">
              <Image className="h-4 w-4 mr-2" />
              Stories ({stories.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="posts" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {posts.map(post => (
                <ContentCard key={post.id} item={post} />
              ))}
              {posts.length === 0 && (
                <div className="col-span-full text-center py-12 bg-muted/30 rounded-lg">
                  <Image className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Nenhum post gerado ainda</p>
                  <p className="text-sm text-muted-foreground mt-2">Clique em "Gerar novo conteúdo" para começar</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="stories" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {stories.map(story => (
                <ContentCard key={story.id} item={story} />
              ))}
              {stories.length === 0 && (
                <div className="col-span-full text-center py-12 bg-muted/30 rounded-lg">
                  <Image className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Nenhum story gerado ainda</p>
                  <p className="text-sm text-muted-foreground mt-2">Clique em "Gerar novo conteúdo" para começar</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="mt-12 p-6 bg-muted/30 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Como usar este gerador</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="font-medium">1. Configure suas preferências</div>
              <p className="text-sm text-muted-foreground">
                Defina temas, estilos de imagem e tipos de mensagens nas configurações.
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-medium">2. Gere ou agende conteúdo</div>
              <p className="text-sm text-muted-foreground">
                Crie conteúdo manualmente ou configure a geração automática diária.
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-medium">3. Baixe e publique</div>
              <p className="text-sm text-muted-foreground">
                Baixe as imagens geradas e publique-as manualmente no Instagram.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
