'use client'
import { useEffect, useState } from 'react'
import { ContentItem, generateContent } from '@/lib/api'
import { ContentGenerationConfig, defaultConfig, loadConfig, scheduleContentGeneration } from '@/lib/scheduler'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Clock, RefreshCw } from 'lucide-react'

export default function SchedulerPage() {
  const [config, setConfig] = useState<ContentGenerationConfig>(defaultConfig)
  const [nextGeneration, setNextGeneration] = useState<Date | null>(null)
  const [timeRemaining, setTimeRemaining] = useState<string>('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [lastGenerated, setLastGenerated] = useState<string>('')
  const [schedulerId, setSchedulerId] = useState<number | null>(null)

  // Carregar configurações ao iniciar
  useEffect(() => {
    const loadUserConfig = async () => {
      try {
        const userConfig = await loadConfig()
        setConfig(userConfig)
        scheduleNextGeneration(userConfig)
      } catch (error) {
        console.error('Erro ao carregar configurações:', error)
      }
    }

    loadUserConfig()

    // Limpar agendamento ao desmontar componente
    return () => {
      if (schedulerId !== null) {
        clearTimeout(schedulerId)
      }
    }
  }, [])

  // Atualizar contador de tempo restante
  useEffect(() => {
    if (!nextGeneration) return

    const interval = setInterval(() => {
      const now = new Date()
      const diff = nextGeneration.getTime() - now.getTime()

      if (diff <= 0) {
        setTimeRemaining('Gerando conteúdo...')
        clearInterval(interval)
        return
      }

      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)

      setTimeRemaining(
        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      )
    }, 1000)

    return () => clearInterval(interval)
  }, [nextGeneration])

  // Função para agendar próxima geração
  const scheduleNextGeneration = (userConfig: ContentGenerationConfig) => {
    // Limpar agendamento anterior se existir
    if (schedulerId !== null) {
      clearTimeout(schedulerId)
    }

    // Calcular próximo horário de geração
    const now = new Date()
    const [hours, minutes] = userConfig.scheduleTime.split(':').map(Number)
    
    let scheduledTime = new Date(now)
    scheduledTime.setHours(hours, minutes, 0, 0)
    
    // Se o horário já passou hoje, agendar para amanhã
    if (scheduledTime <= now) {
      scheduledTime.setDate(scheduledTime.getDate() + 1)
    }
    
    setNextGeneration(scheduledTime)

    // Agendar geração
    const id = scheduleContentGeneration(userConfig, handleGenerateContent)
    setSchedulerId(id)
  }

  // Função para gerar conteúdo
  const handleGenerateContent = async () => {
    setIsGenerating(true)
    
    try {
      // Gerar conteúdo com base nas configurações
      const newContent = await generateContent('all', config.postCount + config.storyCount)
      
      // Aqui seria implementada a lógica para salvar o conteúdo gerado
      console.log('Conteúdo gerado:', newContent)
      
      // Atualizar última geração
      const now = new Date()
      setLastGenerated(now.toLocaleString())
      
      // Reagendar próxima geração
      scheduleNextGeneration(config)
    } catch (error) {
      console.error('Erro ao gerar conteúdo:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  // Função para forçar geração imediata
  const handleForceGeneration = () => {
    handleGenerateContent()
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Agendamento</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Próxima Geração</CardTitle>
            <CardDescription>
              Informações sobre o agendamento de geração de conteúdo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Horário programado:</span>
              <span className="text-sm">{config.scheduleTime}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Próxima geração:</span>
              <span className="text-sm">
                {nextGeneration ? nextGeneration.toLocaleString() : 'Não agendado'}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Tempo restante:</span>
              <span className="text-sm font-mono bg-muted px-2 py-1 rounded">
                {timeRemaining || '--:--:--'}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Última geração:</span>
              <span className="text-sm">
                {lastGenerated || 'Nenhuma geração realizada'}
              </span>
            </div>

            <Button 
              onClick={handleForceGeneration} 
              disabled={isGenerating}
              className="w-full mt-4"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Gerando conteúdo...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Gerar agora
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Configurações Atuais</CardTitle>
            <CardDescription>
              Resumo das configurações de geração de conteúdo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="text-sm font-medium">Temas:</h3>
              <p className="text-sm text-muted-foreground">
                {config.themes.join(', ')}
              </p>
            </div>

            <div>
              <h3 className="text-sm font-medium">Tipos de mensagens:</h3>
              <p className="text-sm text-muted-foreground">
                {config.includeReligious && config.includeNonReligious
                  ? 'Religiosas e não-religiosas'
                  : config.includeReligious
                  ? 'Apenas religiosas'
                  : 'Apenas não-religiosas'}
              </p>
            </div>

            <div>
              <h3 className="text-sm font-medium">Estilo de imagem:</h3>
              <p className="text-sm text-muted-foreground">{config.imageStyle}</p>
            </div>

            <div>
              <h3 className="text-sm font-medium">Quantidade diária:</h3>
              <p className="text-sm text-muted-foreground">
                {config.postCount} post(s) e {config.storyCount} story(ies)
              </p>
            </div>

            <div className="pt-4">
              <Button variant="outline" className="w-full" onClick={() => window.location.href = '/configuracoes'}>
                <Clock className="h-4 w-4 mr-2" />
                Alterar configurações
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
