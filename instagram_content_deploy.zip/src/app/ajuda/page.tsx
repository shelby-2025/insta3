'use client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { AlertCircle, CheckCircle2, HelpCircle } from 'lucide-react'
import { useState } from 'react'

export default function HelpPage() {
  const [activeTab, setActiveTab] = useState('inicio')

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2 text-center">Ajuda e Instruções</h1>
      <p className="text-center text-muted-foreground mb-8">
        Aprenda a usar o Gerador de Conteúdo para Instagram de forma eficiente
      </p>

      <div className="max-w-4xl mx-auto">
        <Tabs defaultValue="inicio" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-8">
            <TabsTrigger value="inicio">Início</TabsTrigger>
            <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
            <TabsTrigger value="dicas">Dicas e Truques</TabsTrigger>
          </TabsList>
          
          <TabsContent value="inicio" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Como Começar</CardTitle>
                <CardDescription>
                  Primeiros passos para usar o gerador de conteúdo
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-medium">1. Navegue pela aplicação</h3>
                  <p className="text-sm text-muted-foreground">
                    Use o menu de navegação para acessar as diferentes seções: Início, Configurações e Agendamento.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">2. Configure suas preferências</h3>
                  <p className="text-sm text-muted-foreground">
                    Acesse a página de Configurações para personalizar os temas, estilos de imagem e tipos de mensagens.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">3. Gere conteúdo</h3>
                  <p className="text-sm text-muted-foreground">
                    Na página inicial, clique em "Gerar novo conteúdo" para criar posts e stories instantaneamente.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">4. Configure o agendamento</h3>
                  <p className="text-sm text-muted-foreground">
                    Na página de Agendamento, defina um horário para geração automática diária de conteúdo.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">5. Baixe e publique</h3>
                  <p className="text-sm text-muted-foreground">
                    Baixe as imagens geradas clicando no botão "Baixar" e publique-as manualmente no Instagram.
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" onClick={() => setActiveTab('configuracoes')}>
                  Próximo: Configurações
                </Button>
              </CardFooter>
            </Card>
            
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Importante</AlertTitle>
              <AlertDescription>
                Este sistema gera conteúdo automaticamente, mas a publicação no Instagram deve ser feita manualmente.
              </AlertDescription>
            </Alert>
          </TabsContent>
          
          <TabsContent value="configuracoes" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurações</CardTitle>
                <CardDescription>
                  Como personalizar a geração de conteúdo
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-medium">Temas</h3>
                  <p className="text-sm text-muted-foreground">
                    Defina os temas para seu conteúdo, separados por vírgulas. Exemplos: desenvolvimento pessoal, 
                    espiritualidade, superação, gratidão, fé, propósito.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Tipos de Mensagens</h3>
                  <p className="text-sm text-muted-foreground">
                    Escolha entre mensagens religiosas (baseadas em versículos bíblicos e princípios cristãos), 
                    mensagens não-religiosas (focadas em desenvolvimento pessoal), ou ambas.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Estilo de Imagem</h3>
                  <p className="text-sm text-muted-foreground">
                    Descreva o estilo visual desejado para as imagens. Exemplos: paisagens naturais, 
                    nascer do sol, montanhas, céu estrelado, etc.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Quantidade de Conteúdo</h3>
                  <p className="text-sm text-muted-foreground">
                    Defina quantos posts (1-5) e stories (1-10) deseja gerar diariamente.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Horário de Geração</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure o horário para geração automática diária de conteúdo.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setActiveTab('inicio')}>
                  Anterior: Início
                </Button>
                <Button variant="outline" onClick={() => setActiveTab('dicas')}>
                  Próximo: Dicas
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="dicas" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Dicas e Truques</CardTitle>
                <CardDescription>
                  Como obter os melhores resultados
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-medium">Seja específico nos temas</h3>
                  <p className="text-sm text-muted-foreground">
                    Em vez de usar temas genéricos como "motivação", use temas mais específicos como 
                    "superação de desafios" ou "gratidão diária" para obter conteúdo mais relevante.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Descreva o estilo visual com detalhes</h3>
                  <p className="text-sm text-muted-foreground">
                    Quanto mais detalhada for a descrição do estilo de imagem, melhores serão os resultados. 
                    Exemplo: "paisagens montanhosas ao amanhecer com tons dourados".
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Combine mensagens religiosas e não-religiosas</h3>
                  <p className="text-sm text-muted-foreground">
                    Para maior variedade de conteúdo, habilite tanto mensagens religiosas quanto não-religiosas.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Verifique o conteúdo antes de postar</h3>
                  <p className="text-sm text-muted-foreground">
                    Sempre revise o conteúdo gerado antes de publicar no Instagram para garantir que 
                    está alinhado com seus valores e objetivos.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Atualize seus temas periodicamente</h3>
                  <p className="text-sm text-muted-foreground">
                    Para manter seu conteúdo fresco e engajante, atualize seus temas e estilos de imagem regularmente.
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" onClick={() => setActiveTab('configuracoes')}>
                  Anterior: Configurações
                </Button>
              </CardFooter>
            </Card>
            
            <Alert variant="default" className="bg-primary/10 border-primary/20">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              <AlertTitle>Dica profissional</AlertTitle>
              <AlertDescription>
                Para melhores resultados, gere vários conjuntos de conteúdo e selecione os melhores para publicação.
                Isso permite maior controle sobre a qualidade do que é compartilhado em seu perfil.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>
        
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">
            Ainda tem dúvidas? Entre em contato conosco para obter ajuda adicional.
          </p>
        </div>
      </div>
    </div>
  )
}
