'use client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { zodResolver } from '@hookform/resolvers/zod'
import { Clock, Save } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import * as z from 'zod'
import { ContentGenerationConfig, defaultConfig, loadConfig, saveConfig } from '@/lib/scheduler'

const formSchema = z.object({
  themes: z.string().min(1, {
    message: 'Adicione pelo menos um tema.',
  }),
  includeReligious: z.boolean().default(true),
  includeNonReligious: z.boolean().default(true),
  imageStyle: z.string().min(1, {
    message: 'Descreva o estilo de imagem desejado.',
  }),
  postCount: z.coerce.number().min(1).max(5),
  storyCount: z.coerce.number().min(1).max(10),
  scheduleTime: z.string(),
})

export default function SettingsPage() {
  const [isSaving, setIsSaving] = useState(false)
  const [savedMessage, setSavedMessage] = useState('')

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      themes: defaultConfig.themes.join(', '),
      includeReligious: defaultConfig.includeReligious,
      includeNonReligious: defaultConfig.includeNonReligious,
      imageStyle: defaultConfig.imageStyle,
      postCount: defaultConfig.postCount,
      storyCount: defaultConfig.storyCount,
      scheduleTime: defaultConfig.scheduleTime,
    },
  })

  useEffect(() => {
    const loadSavedConfig = async () => {
      try {
        const config = await loadConfig()
        form.reset({
          themes: config.themes.join(', '),
          includeReligious: config.includeReligious,
          includeNonReligious: config.includeNonReligious,
          imageStyle: config.imageStyle,
          postCount: config.postCount,
          storyCount: config.storyCount,
          scheduleTime: config.scheduleTime,
        })
      } catch (error) {
        console.error('Erro ao carregar configurações:', error)
      }
    }

    loadSavedConfig()
  }, [form])

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSaving(true)
    setSavedMessage('')

    try {
      const config: ContentGenerationConfig = {
        themes: values.themes.split(',').map(theme => theme.trim()),
        includeReligious: values.includeReligious,
        includeNonReligious: values.includeNonReligious,
        imageStyle: values.imageStyle,
        postCount: values.postCount,
        storyCount: values.storyCount,
        scheduleTime: values.scheduleTime,
      }

      await saveConfig(config)
      setSavedMessage('Configurações salvas com sucesso!')
    } catch (error) {
      console.error('Erro ao salvar configurações:', error)
      setSavedMessage('Erro ao salvar configurações. Tente novamente.')
    } finally {
      setIsSaving(false)
      
      // Limpar mensagem após 3 segundos
      setTimeout(() => {
        setSavedMessage('')
      }, 3000)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Configurações</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Geração de Conteúdo</CardTitle>
            <CardDescription>
              Configure os parâmetros para geração automática de conteúdo
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="themes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Temas</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="desenvolvimento pessoal, espiritualidade, superação"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Separe os temas por vírgulas.
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="includeReligious"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                        <div className="space-y-0.5">
                          <FormLabel>Mensagens Religiosas</FormLabel>
                          <FormDescription>
                            Incluir mensagens cristãs
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="includeNonReligious"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                        <div className="space-y-0.5">
                          <FormLabel>Mensagens Não-Religiosas</FormLabel>
                          <FormDescription>
                            Incluir mensagens motivacionais
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="imageStyle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estilo de Imagem</FormLabel>
                      <FormControl>
                        <Input placeholder="paisagens naturais" {...field} />
                      </FormControl>
                      <FormDescription>
                        Descreva o estilo visual das imagens.
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="postCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Número de Posts</FormLabel>
                        <FormControl>
                          <Input type="number" min={1} max={5} {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="storyCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Número de Stories</FormLabel>
                        <FormControl>
                          <Input type="number" min={1} max={10} {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="scheduleTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Horário de Geração</FormLabel>
                      <FormControl>
                        <div className="flex items-center">
                          <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                          <Input type="time" {...field} />
                        </div>
                      </FormControl>
                      <FormDescription>
                        Horário para geração automática diária.
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <Button type="submit" disabled={isSaving}>
                  {isSaving ? (
                    <>Salvando...</>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Salvar Configurações
                    </>
                  )}
                </Button>

                {savedMessage && (
                  <p className={`text-sm ${savedMessage.includes('Erro') ? 'text-red-500' : 'text-green-500'}`}>
                    {savedMessage}
                  </p>
                )}
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Informações</CardTitle>
            <CardDescription>
              Como funciona o gerador de conteúdo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-medium">Geração Automática</h3>
              <p className="text-sm text-muted-foreground">
                O sistema gerará automaticamente o conteúdo diariamente no horário configurado.
                Você receberá 5 stories e 1 post por dia, que poderão ser baixados e postados
                manualmente no Instagram.
              </p>
            </div>

            <div>
              <h3 className="font-medium">Temas e Estilos</h3>
              <p className="text-sm text-muted-foreground">
                Os temas definidos serão utilizados para gerar tanto as imagens quanto os textos.
                Quanto mais específicos forem os temas e o estilo de imagem, melhores serão os resultados.
              </p>
            </div>

            <div>
              <h3 className="font-medium">Tipos de Mensagens</h3>
              <p className="text-sm text-muted-foreground">
                Você pode escolher incluir mensagens religiosas (baseadas em versículos bíblicos e
                princípios cristãos) e/ou mensagens motivacionais não-religiosas (focadas em
                desenvolvimento pessoal e superação).
              </p>
            </div>

            <div>
              <h3 className="font-medium">Dicas para Melhores Resultados</h3>
              <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                <li>Use temas específicos como "gratidão", "perseverança", "fé"</li>
                <li>Descreva o estilo visual com detalhes (ex: "paisagens montanhosas ao amanhecer")</li>
                <li>Combine mensagens religiosas e não-religiosas para maior variedade</li>
                <li>Verifique o conteúdo antes de postar para garantir qualidade</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
